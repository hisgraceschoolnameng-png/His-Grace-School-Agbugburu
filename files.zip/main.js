// =============================================================
// HIS GRACE SCHOOL AGBUGBURU — main.js
// Shared front-end behaviour for all pages (Phase 1: no backend
// calls yet). Firebase-powered features are added in a later
// phase via js/firebase-config.js.
// =============================================================

document.addEventListener('DOMContentLoaded', function () {
  // ---- Footer year ---------------------------------------------------
  var yearEl = document.getElementById('year');
  if (yearEl) {
    yearEl.textContent = new Date().getFullYear();
  }

  // ---- Mobile navigation toggle ---------------------------------------
  var navToggle = document.getElementById('navToggle');
  var navLinks = document.getElementById('navLinks');

  if (navToggle && navLinks) {
    navToggle.addEventListener('click', function () {
      var isOpen = navLinks.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });

    // Close the menu after a link is tapped (mobile UX nicety)
    navLinks.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        navLinks.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  // ---- Contact form (placeholder — no backend wired up yet) ----------
  var contactForm = document.getElementById('contactForm');
  var formStatus = document.getElementById('formStatus');

  if (contactForm && formStatus) {
    contactForm.addEventListener('submit', function (event) {
      event.preventDefault();

      // Phase 1: the form does not send data anywhere yet.
      // In a later phase this will write to Firebase Firestore
      // (see js/firebase-config.js for where that connection
      // will be configured).
      formStatus.textContent =
        'Thanks — message forms aren\'t connected yet. Please call 0813 760 6078 in the meantime.';

      contactForm.reset();
    });
  }
});
