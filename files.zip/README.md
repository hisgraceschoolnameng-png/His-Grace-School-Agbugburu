# His Grace School Agbugburu — Website & Portal

Official website project for **His Grace School Agbugburu**.

- **Address:** Agbugburu Village, Odeda Local Government, Abeokuta, Ogun State, Nigeria
- **Phone:** 0813 760 6078

This repository is being built in phases. **Phase 1** (this phase) is the
public-facing school website. A later phase will add a secure school
management portal (student/teacher/admin accounts, results, etc.) on top of
the same Firebase project.

---

## Tech stack

| Layer | Choice |
|---|---|
| Frontend | HTML, CSS, vanilla JavaScript (no framework/build step) |
| Backend | Firebase (Auth + Firestore) — added in a later phase |
| Database | Firebase Firestore — added in a later phase |
| Image/media storage | Cloudinary — added in a later phase |
| Hosting | GitHub Pages |

There is intentionally no Next.js, no Prisma, and no Node server in this
project — everything runs as static files that GitHub Pages can serve
directly, with Firebase and Cloudinary handling backend concerns from the
browser.

---

## Project structure

```
/
├── index.html              Home page
├── about.html              About Us page
├── contact.html            Contact Us page
├── css/
│   └── style.css           All site styling (design tokens at the top)
├── js/
│   ├── main.js              Nav toggle, footer year, contact form UI logic
│   ├── firebase-config.js   Firebase config placeholder (see below)
│   └── cloudinary-config.js Cloudinary config placeholder (see below)
├── assets/
│   ├── images/              Photos go here (empty for now)
│   └── icons/
│       └── crest.svg        School crest / logo used in header & footer
├── README.md
└── .gitignore
```

## Current Phase 1 status

- [x] Home page
- [x] About Us page
- [x] Contact Us page (front-end form only — not yet wired to a backend)
- [x] Sticky navigation bar with responsive/mobile hamburger menu
- [x] Shared footer with contact details on every page
- [x] Mobile, tablet, and desktop responsive layout
- [x] School crest/logo used consistently as branding
- [ ] Real school history / founding story (placeholder copy used — see notices on Home and About pages)
- [ ] Firebase connected (Phase 2+)
- [ ] Cloudinary connected (Phase 2+)
- [ ] School management portal (Phase 2+)

---

## Deploying with GitHub Pages

1. Push this repository's contents to the `main` branch (or your default branch).
2. In GitHub, go to **Settings → Pages**.
3. Under **Build and deployment → Source**, choose **Deploy from a branch**.
4. Choose branch `main` and folder `/ (root)`, then **Save**.
5. GitHub will publish the site at a URL in this format:

   ```
   https://<github-username>.github.io/<repository-name>/
   ```

   For this project, that is expected to be:

   ```
   https://hisgraceschoolnameng-png.github.io/His-Grace-School-Agbugburu/
   ```

It can take a minute or two after saving for the site to go live or update.

---

## Firebase setup (pending — for a later phase)

`js/firebase-config.js` contains a placeholder configuration object and is
**not yet connected** to any page. When you're ready to start Phase 2:

1. Create a project at [console.firebase.google.com](https://console.firebase.google.com).
2. Add a Web App to the project to get your config values (`apiKey`,
   `authDomain`, `projectId`, etc.).
3. Replace the placeholder values in `js/firebase-config.js` with the real
   ones.
4. Add the Firebase SDK `<script>` tags to whichever pages need
   Authentication/Firestore (the portal pages — the public site pages in
   this Phase 1 do not need them).
5. Set up Firestore Security Rules before storing any real student data.

No real Firebase credentials have been created or committed in this phase.

## Cloudinary setup (pending — for a later phase)

`js/cloudinary-config.js` contains a placeholder configuration object and is
**not yet connected** to any page.

1. Create a free account at [cloudinary.com](https://cloudinary.com).
2. Note your **Cloud Name** from the dashboard.
3. Create an **unsigned** upload preset under
   **Settings → Upload → Upload presets** (this lets the front-end upload
   images without exposing your API secret).
4. Replace the placeholder `cloudName` and `uploadPreset` values in
   `js/cloudinary-config.js`.

Never put your Cloudinary **API Secret** in this repository or in any
front-end file — only the Cloud Name and an unsigned preset name belong in
client-side code.

---

## Local development

No build step is required. Open `index.html` directly in a browser, or serve
the folder with any static file server, for example:

```bash
npx serve .
```

---

## Roadmap

- **Phase 1 (this phase):** Public website — Home, About, Contact.
- **Phase 2:** Firebase Authentication + Firestore wired up; Cloudinary
  wired up for image uploads (e.g. a photo gallery, news/announcements).
- **Phase 3+:** School management portal — student, teacher, and admin
  roles; CBT exams; results and report cards.
