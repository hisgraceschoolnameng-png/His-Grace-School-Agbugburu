// =============================================================
// HIS GRACE SCHOOL AGBUGBURU — firebase-config.js
//
// This file is a PLACEHOLDER for the Firebase configuration that
// will power Authentication and Firestore in a later phase of
// this project (the school management portal).
//
// It is NOT wired into any page yet in Phase 1. No real
// credentials are included here.
//
// -------------------------------------------------------------
// HOW THIS WILL WORK LATER
// -------------------------------------------------------------
// 1. Create a Firebase project at https://console.firebase.google.com
// 2. Add a "Web App" to that project.
// 3. Firebase will give you a config object containing values
//    like apiKey, authDomain, projectId, etc.
// 4. Replace the placeholder values below with the REAL values
//    from your Firebase project settings.
// 5. Add the Firebase SDK <script> tags to the pages that need
//    them (only the portal pages will need this in a later
//    phase — the public site does not).
//
// -------------------------------------------------------------
// IMPORTANT — ABOUT SECRETS
// -------------------------------------------------------------
// Firebase's client-side "apiKey" is not a secret in the same
// way a server API key is — it identifies your Firebase project
// to Google, and access is actually controlled by Firestore
// Security Rules and Firebase Authentication, not by hiding this
// value. Even so, do NOT commit your real values into a public
// GitHub repository until Firestore Security Rules are properly
// configured to restrict access. If this repository is public,
// consider keeping real config values out of version control
// (e.g. loaded from a separate untracked file or environment-
// specific build step) until the portal phase is built out.
// =============================================================

const firebaseConfig = {
  apiKey: "PLACEHOLDER_API_KEY",
  authDomain: "PLACEHOLDER_PROJECT_ID.firebaseapp.com",
  projectId: "PLACEHOLDER_PROJECT_ID",
  storageBucket: "PLACEHOLDER_PROJECT_ID.appspot.com",
  messagingSenderId: "PLACEHOLDER_SENDER_ID",
  appId: "PLACEHOLDER_APP_ID"
};

// Firebase SDK initialization is intentionally NOT performed here
// yet. Once the SDK <script> tags are added to the relevant
// pages in a later phase, initialization will look like:
//
//   const app = firebase.initializeApp(firebaseConfig);
//   const auth = firebase.auth();
//   const db = firebase.firestore();
//
// Exporting the config object now so it is ready to be imported
// once that phase begins.
if (typeof module !== 'undefined' && module.exports) {
  module.exports = firebaseConfig;
}
