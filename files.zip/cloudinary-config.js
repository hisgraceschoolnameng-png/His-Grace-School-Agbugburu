// =============================================================
// HIS GRACE SCHOOL AGBUGBURU — cloudinary-config.js
//
// PLACEHOLDER for future Cloudinary image/media upload settings.
// Not wired into any page yet in Phase 1. No real credentials
// are included here.
//
// -------------------------------------------------------------
// HOW THIS WILL WORK LATER
// -------------------------------------------------------------
// Cloudinary uploads from a plain front-end (no Node/Next.js
// server) are normally done with an UNSIGNED upload preset, so
// that only a public cloud name + preset name are needed in
// front-end code — never your API secret.
//
// 1. Create a free account at https://cloudinary.com
// 2. Note your "Cloud Name" from the Cloudinary dashboard.
// 3. Create an UNSIGNED upload preset under
//    Settings > Upload > Upload presets.
// 4. Replace the placeholders below with your real Cloud Name
//    and preset name.
//
// -------------------------------------------------------------
// IMPORTANT — ABOUT SECRETS
// -------------------------------------------------------------
// Never put your Cloudinary API Secret in front-end code or in
// this repository. Only the Cloud Name and an UNSIGNED preset
// name belong here. Anything that requires the API Secret
// (e.g. deleting images, signed uploads) must go through a
// small backend function, which is out of scope for this plain
// HTML/CSS/JS + GitHub Pages phase.
// =============================================================

const cloudinaryConfig = {
  cloudName: "PLACEHOLDER_CLOUD_NAME",
  uploadPreset: "PLACEHOLDER_UNSIGNED_UPLOAD_PRESET"
};

if (typeof module !== 'undefined' && module.exports) {
  module.exports = cloudinaryConfig;
}
